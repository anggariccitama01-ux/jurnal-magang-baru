<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Pembimbing; 

class ProfilController extends Controller
{
    public function show()
{
    $user = Auth::user();

    // Jika yang masuk adalah akun siswa
    if ($user && $user->role === 'siswa') {
        $pembimbing = $user->pembimbing;
        $daftar_pembimbing = \App\Models\Pembimbing::all();

        return view('profil_siswa', compact('user', 'pembimbing', 'daftar_pembimbing'));
    }

    // Jika yang masuk adalah akun pembimbing (atau role lainnya)
    return view('profil_pembimbing', compact('user'));
}
}
