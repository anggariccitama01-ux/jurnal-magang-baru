<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Pembimbing - Jurnal Magang</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f6f9; color: #333; padding: 40px 0; margin: 0; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
        .header-box { background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 6px rgba(0,0,0,0.02); margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; border-left: 5px solid #20c997; }
        .text-success { color: #20c997; margin: 0; font-weight: 700; font-size: 26px; }
        .card { background: #fff; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.02); border: none; overflow: hidden; }
        .table-responsive { width: 100%; overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th { background-color: #e8faf4; color: #0f5132; padding: 16px; text-transform: uppercase; font-size: 11px; font-weight: 700; border-bottom: 2px solid #dee2e6; }
        td { padding: 16px; border-bottom: 1px solid #dee2e6; color: #495057; font-size: 14px; vertical-align: top; }
        tr:hover { background-color: #f8f9fa; }
        .form-control { width: 100%; padding: 8px 10px; font-size: 13px; border-radius: 6px; border: 2px solid #dee2e6; box-sizing: border-box; font-family: inherit; }
        .form-control:focus { border-color: #20c997; outline: none; }
        .btn { font-weight: 600; text-decoration: none; padding: 8px 14px; font-size: 12px; border-radius: 6px; cursor: pointer; border: none; font-family: inherit; }
        .btn-success { background-color: #20c997; color: #fff; }
        .btn-success:hover { background-color: #198754; }
        .badge-danger { background: #f8d7da; color: #842029; padding: 4px 8px; border-radius: 6px; font-size: 12px; font-weight: 600; border: 1px solid #f5c2c7; }
        .badge-success { background: #d1e7dd; color: #0f5132; padding: 4px 8px; border-radius: 6px; font-size: 12px; font-weight: 600; border: 1px solid #badbcc; }
        .alert { padding: 15px 20px; background-color: #d1e7dd; color: #0f5132; border-radius: 8px; margin-bottom: 24px; font-weight: 600; border-left: 5px solid #0f5132; }
        .comment-box { background-color: #f8f9fa; padding: 10px; border-radius: 6px; border-left: 3px solid #6c757d; font-size: 13px; margin-top: 5px; color: #212529; font-style: italic; }
    </style>
</head>
<body>
    <div class="container">
        
        <!-- HEADER BOX -->
        <div class="header-box">
            <div>
                <h2 class="text-success">👨‍🏫 Panel Pembimbing Magang</h2>
                <small style="color: #6c757d;">Silakan periksa aktivitas harian mahasiswa dan berikan penilaian/catatan.</small>
            </div>
            <div>
                <a href="<?php echo e(route('journals.index')); ?>" style="background-color: #6c757d; color: white; text-decoration: none; padding: 10px 16px; border-radius: 6px; font-size: 14px; font-weight: 600;">Ke Halaman Utama</a>
            </div>
        </div>

        <?php if(session('success')): ?>
            <div class="alert">✨ <?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <!-- TABEL UTAMA PENILAIAN JURNAL -->
        <div class="card">
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th style="width: 5%; text-align: center;">No</th>
                            <th style="width: 15%;">Tanggal</th>
                            <th style="width: 35%;">Aktivitas / Kegiatan</th>
                            <th style="width: 15%;">Kendala Mahasiswa</th>
                            <th style="width: 30%;">Catatan & Penilaian Pembimbing</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $journals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $journal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td style="text-center; font-weight: bold; color: #6c757d;"><?php echo e($index + 1); ?></td>
                                <td style="font-weight: 600;"><?php echo e(date('d M Y', strtotime($journal->tanggal))); ?></td>
                                <td style="white-space: pre-line; line-height: 1.5;"><?php echo e($journal->kegiatan); ?></td>
                                <td>
                                    <?php if($journal->kendala): ?>
                                        <span class="badge-danger">⚠️ <?php echo e($journal->kendala); ?></span>
                                    <?php else: ?>
                                        <span class="badge-success">✅ Lancar</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <!-- Jika sudah ada komentar, tampilkan di atas kotak input -->
                                    <?php if($journal->catatan_pembimbing): ?>
                                        <div class="comment-box">
                                            <b>Catatan aktif:</b> "<?php echo e($journal->catatan_pembimbing); ?>"
                                        </div>
                                    <?php endif; ?>

                                    <!-- Form input komentar pembimbing -->
                                    <form action="<?php echo e(route('pembimbing.komentar', $journal->id)); ?>" method="POST" style="margin-top: 8px; display: flex; gap: 6px;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <input type="text" name="catatan_pembimbing" class="form-control" placeholder="Tulis evaluasi / nilai..." required value="<?php echo e($journal->catatan_pembimbing); ?>">
                                        <button type="submit" class="btn btn-success">Kirim</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" style="text-align: center; color: #6c757d; padding: 50px 0;">Belum ada data jurnal mahasiswa yang diinputkan.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\jurnal-magang-baru\resources\views/journals/pembimbing.blade.php ENDPATH**/ ?>