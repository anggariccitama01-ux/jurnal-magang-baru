<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Biodata Siswa</title>
    <style>
        body { 
            font-family: 'Arial', sans-serif; 
            background-color: #f4f6f9; 
            padding: 40px 20px; 
            margin: 0;
        }
        .card { 
            background: white; 
            max-width: 650px; 
            margin: 0 auto; 
            border-radius: 12px; 
            box-shadow: 0 10px 25px rgba(0,0,0,0.05); 
            overflow: hidden; 
        }
        .header { 
            background: #007bff; 
            color: white; 
            padding: 40px 20px; 
            text-align: center; 
        }
        .avatar { 
            width: 90px; 
            height: 90px; 
            background: white; 
            color: #007bff; 
            border-radius: 50%; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            font-size: 38px; 
            font-weight: bold; 
            margin: 0 auto 15px; 
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        .header h2 {
            margin: 0 0 5px 0;
            font-size: 24px;
        }
        .header p {
            margin: 0;
            opacity: 0.9;
            font-size: 15px;
        }
        .content { 
            padding: 30px; 
        }
        .section-title { 
            margin-top: 30px; 
            font-weight: bold; 
            color: #333; 
            border-bottom: 2px solid #007bff; 
            padding-bottom: 8px;
            font-size: 16px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .row-info { 
            display: flex; 
            padding: 14px 0; 
            border-bottom: 1px solid #f1f1f1; 
            align-items: center;
        }
        .label { 
            width: 180px; 
            font-weight: bold; 
            color: #555; 
        }
        .value { 
            flex-grow: 1; 
            color: #333; 
        }
        .badge { 
            background: #e2f0d9; 
            padding: 4px 12px; 
            border-radius: 20px; 
            font-size: 13px; 
            color: #388e3c; 
            font-weight: bold;
            text-transform: capitalize;
        }
        .alert-success { 
            padding: 12px 15px; 
            background-color: #d4edda; 
            color: #155724; 
            border-radius: 6px; 
            margin-bottom: 20px; 
            border: 1px solid #c3e6cb;
            font-size: 14px;
        }
        .footer-action { 
            display: flex; 
            justify-content: space-between; 
            margin-top: 35px; 
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        .btn { 
            padding: 10px 20px; 
            border: none; 
            border-radius: 6px; 
            cursor: pointer; 
            font-weight: bold; 
            text-decoration: none; 
            display: inline-block; 
            font-size: 14px;
            transition: all 0.2s;
        }
        .btn-primary {
            background-color: #007bff;
            color: white;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .btn-secondary { 
            background-color: #f8f9fa; 
            color: #495057; 
            border: 1px solid #ced4da; 
        }
        .btn-secondary:hover { 
            background-color: #e2e6ea; 
        }
        .btn-warning { 
            background-color: #ffc107; 
            color: #212529; 
        }
        .btn-warning:hover { 
            background-color: #e0a800; 
        }

         /* Sembunyikan tombol navigasi dan cetak otomatis saat masuk ke mode cetak kertas/PDF */
           @media print {
        .footer-action, .btn, button {
            display: none !important;
        }
        /* PAKSA BROWSER UNTUK MEMUNCULKAN WARNA BACKGROUND */
        body, .card, .header, .avatar, .badge {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
        }

        body {
            background-color: #f4f6f9; /* atau set putih jika ingin kertasnya putih bersih */
            padding: 0;
        }

        .card {
            box-shadow: none;
            border: none;
            max-width: 100%;
        }
    }

</style>

    </style>
</head>
<body>

<div class="card">
    <div class="header">
        <div class="avatar"><?php echo e(strtoupper(substr($user->name, 0, 1))); ?></div>
        <h2><?php echo e($user->name); ?></h2>
        <p>Mahasiswa / Siswa Magang Aktif</p>
    </div>

    <div class="content">
        <!-- Notifikasi Sukses -->
        <?php if(session('success')): ?>
            <div class="alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <h4 class="section-title">📌 BIODATA DIRI</h4>
        <div class="row-info">
            <div class="label">Nama Lengkap</div>
            <div class="value">: <?php echo e($user->name); ?></div>
        </div>
        <div class="row-info">
            <div class="label">Alamat Email</div>
            <div class="value">: <?php echo e($user->email); ?></div>
        </div>
        <div class="row-info">
            <div class="label">Status Akses</div>
            <div class="value">: <span class="badge"><?php echo e($user->role); ?></span></div>
        </div>
        <div class="row-info">
            <div class="label">Terdaftar Sejak</div>
            <div class="value">: <?php echo e($user->created_at ? $user->created_at->format('d F Y') : '-'); ?></div>
        </div>

        <h4 class="section-title">🪪 PEMBIMBING LAPANGAN</h4>
        
        <?php if($pembimbing): ?>
            <!-- Tampilan jika sudah terhubung dengan pembimbing -->
            <div class="row-info" style="border-bottom: none; padding-bottom: 0;">
                <div class="label">Nama Pembimbing</div>
                <div class="value" style="color: #28a745; font-weight: bold;">: <?php echo e($pembimbing->nama); ?></div>
            </div>
            <?php if($pembimbing->nip): ?>
                <div class="row-info" style="border-bottom: none; padding-top: 5px;">
                    <div class="label">NIP</div>
                    <div class="value">: <?php echo e($pembimbing->nip); ?></div>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <!-- Tampilan jika belum memilih pembimbing -->
            <div style="color: #856404; background-color: #fff3cd; padding: 15px; border-radius: 8px; border: 1px solid #ffeeba; margin-top: 15px;">
                <p style="margin: 0 0 12px 0; font-weight: bold;">⚠️ Akun Anda belum terhubung dengan Pembimbing Lapangan.</p>
                
                <form action="<?php echo e(route('profil.updatePembimbing')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div style="display: flex; gap: 10px;">
                        <select name="pembimbing_id" id="pembimbing_id" required style="padding: 10px; border-radius: 6px; border: 1px solid #ced4da; flex-grow: 1; background: white; font-size: 14px;">
                            <option value="">-- Pilih Pembimbing --</option>
                            <?php if(isset($daftar_pembimbing) && $daftar_pembimbing->count() > 0): ?>
                                <?php $__currentLoopData = $daftar_pembimbing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pemb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pemb->id); ?>"><?php echo e($pemb->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="" disabled>Data pembimbing belum tersedia</option>
                            <?php endif; ?>
                        </select>
                        <button type="submit" class="btn btn-primary">Hubungkan</button>
                    </div>
                </form>
            </div>
        <?php endif; ?>

        <div class="footer-action">
            <a href="<?php echo e(route('journals.index')); ?>" class="btn btn-secondary">◀ Halaman Utama</a>
            <button class="btn btn-warning" onclick="window.print(' card')">🖨️ Cetak Profil</button>
        </div>
    </div>
</div>

</body>
</html>
<?php /**PATH C:\laragon\www\jurnal-magang-baru\resources\views/profil_siswa.blade.php ENDPATH**/ ?>