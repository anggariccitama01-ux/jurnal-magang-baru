<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Pembimbing Lapangan</title>
    <style>
        body { font-family: 'Arial', sans-serif; background-color: #f4f6f9; padding: 20px; }
        .card { background: white; max-width: 600px; margin: 0 auto; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); overflow: hidden; }
        .header { background: #28a745; color: white; padding: 30px; text-align: center; }
        .avatar { width: 80px; height: 80px; background: white; color: #28a745; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 36px; font-weight: bold; margin: 0 auto 10px; }
        .content { padding: 20px; }
        .row-info { display: flex; padding: 10px 0; border-bottom: 1px solid #eee; }
        .label { width: 150px; font-weight: bold; color: #555; }
        .value { flex-grow: 1; color: #333; }
        .badge { background: #e2e8f0; padding: 3px 8px; border-radius: 4px; font-size: 14px; color: #4a5568; text-transform: capitalize; }
        .section-title { margin-top: 25px; font-weight: bold; color: #333; border-bottom: 2px solid #28a745; padding-bottom: 5px; }
        .btn { padding: 8px 15px; border: none; border-radius: 4px; cursor: pointer; font-weight: bold; text-decoration: none; display: inline-block; }
        .btn-secondary { background-color: #6c757d; color: white; }
        .btn-warning { background-color: #ffc107; color: #212529; }
        .footer-action { display: flex; justify-content: space-between; margin-top: 25px; }
    </style>
</head>
<body>

<div class="card">
    <div class="header">
        <div class="avatar"><?php echo e(strtoupper(substr($user->name, 0, 1))); ?></div>
        <h2><?php echo e($user->name); ?></h2>
        <p>Gelar / Pembimbing Lapangan Aktif</p>
    </div>

    <div class="content">
        <h4 class="section-title">📌 BIODATA PEMBIMBING</h4>
        
        <div class="row-info">
            <div class="label">Nama Lengkap</div>
            <div class="value">: <?php echo e($user->name); ?></div>
        </div>
        <div class="row-info">
            <div class="label">Alamat Email</div>
            <div class="value">: <?php echo e($user->email); ?></div>
        </div>
        <div class="row-info">
            <div class="label">Status Akses</div>
            <div class="value">: <span class="badge" style="background-color: #d4edda; color: #155724;"><?php echo e($user->role); ?></span></div>
        </div>
        <div class="row-info">
            <div class="label">Terdaftar Sejak</div>
            <div class="value">: <?php echo e($user->created_at ? $user->created_at->format('d F Y') : '-'); ?></div>
        </div>

        <div class="footer-action">
            <!-- Mengarah ke dashboard pembimbing sesuai routes/web.php Anda -->
            <a href="<?php echo e(route('pembimbing.index')); ?>" class="btn btn-secondary">◀ Halaman Utama</a>
            <button class="btn btn-warning" onclick="window.print()">🖨️ Cetak Profil</button>
        </div>
    </div>
</div>

</body>
</html>
<?php /**PATH C:\laragon\www\jurnal-magang-baru\resources\views/profil_pembimbing.blade.php ENDPATH**/ ?>