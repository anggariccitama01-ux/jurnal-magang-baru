<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Pembimbing - Jurnal Magang</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f6f9; color: #333; padding: 40px 0; margin: 0; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
        .header-box { background: #fff; border-radius: 12px; padding: 25px; box-shadow: 0 4px 6px rgba(0,0,0,0.02); margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; border-left: 5px solid #20c997; }
        .text-success { color: #20c997; margin: 0; font-weight: 700; font-size: 26px; }
        .card { background: #fff; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.02); border: none; overflow: hidden; }
        .table-responsive { width: 100%; overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th { background-color: #e8faf4; color: #0f5132; padding: 16px; text-transform: uppercase; font-size: 11px; font-weight: 700; border-bottom: 2px solid #dee2e6; }
        td { padding: 16px; border-bottom: 1px solid #dee2e6; color: #495057; font-size: 14px; vertical-align: top; }
        tr:hover { background-color: #f8f9fa; }
        .form-control { width: 100%; padding: 8px 10px; font-size: 13px; border-radius: 6px; border: 2px solid #dee2e6; box-sizing: border-box; font-family: inherit; }
        .form-control:focus { border-color: #20c997; outline: none; }
        .btn { font-weight: 600; text-decoration: none; padding: 8px 14px; font-size: 12px; border-radius: 6px; cursor: pointer; border: none; font-family: inherit; }
        .btn-success { background-color: #20c997; color: #fff; }
        .btn-success:hover { background-color: #198754; }
        .badge-danger { background: #f8d7da; color: #842029; padding: 4px 8px; border-radius: 6px; font-size: 12px; font-weight: 600; border: 1px solid #f5c2c7; }
        .badge-success { background: #d1e7dd; color: #0f5132; padding: 4px 8px; border-radius: 6px; font-size: 12px; font-weight: 600; border: 1px solid #badbcc; }
        .alert { padding: 15px 20px; background-color: #d1e7dd; color: #0f5132; border-radius: 8px; margin-bottom: 24px; font-weight: 600; border-left: 5px solid #0f5132; }
        .comment-box { background-color: #f8f9fa; padding: 10px; border-radius: 6px; border-left: 3px solid #6c757d; font-size: 13px; margin-top: 5px; color: #212529; font-style: italic; }
    </style>
</head>
<body>
    <div class="container">
        
        <!-- HEADER BOX -->
        <div class="header-box">
            <div>
                <h2 class="text-success">👨‍🏫 Panel Pembimbing Magang</h2>
                <small style="color: #6c757d;">Silakan periksa aktivitas harian mahasiswa dan berikan penilaian/catatan.</small>
            </div>
            <div>
                <a href="{{ route('journals.index') }}" style="background-color: #6c757d; color: white; text-decoration: none; padding: 10px 16px; border-radius: 6px; font-size: 14px; font-weight: 600;">Ke Halaman Utama</a>
            </div>
        </div>

        @if(session('success'))
            <div class="alert">✨ {{ session('success') }}</div>
        @endif

        <!-- TABEL UTAMA PENILAIAN JURNAL -->
        <div class="card">
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th style="width: 5%; text-align: center;">No</th>
                            <th style="width: 15%;">Tanggal</th>
                            <th style="width: 35%;">Aktivitas / Kegiatan</th>
                            <th style="width: 15%;">Kendala Mahasiswa</th>
                            <th style="width: 30%;">Catatan & Penilaian Pembimbing</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($journals as $index => $journal)
                            <tr>
                                <td style="text-center; font-weight: bold; color: #6c757d;">{{ $index + 1 }}</td>
                                <td style="font-weight: 600;">{{ date('d M Y', strtotime($journal->tanggal)) }}</td>
                                <td style="white-space: pre-line; line-height: 1.5;">{{ $journal->kegiatan }}</td>
                                <td>
                                    @if($journal->kendala)
                                        <span class="badge-danger">⚠️ {{ $journal->kendala }}</span>
                                    @else
                                        <span class="badge-success">✅ Lancar</span>
                                    @endif
                                </td>
                                <td>
                                    <!-- Jika sudah ada komentar, tampilkan di atas kotak input -->
                                    @if($journal->catatan_pembimbing)
                                        <div class="comment-box">
                                            <b>Catatan aktif:</b> "{{ $journal->catatan_pembimbing }}"
                                        </div>
                                    @endif

                                    <!-- Form input komentar pembimbing -->
                                    <form action="{{ route('pembimbing.komentar', $journal->id) }}" method="POST" style="margin-top: 8px; display: flex; gap: 6px;">
                                        @csrf
                                        @method('PUT')
                                        <input type="text" name="catatan_pembimbing" class="form-control" placeholder="Tulis evaluasi / nilai..." required value="{{ $journal->catatan_pembimbing }}">
                                        <button type="submit" class="btn btn-success">Kirim</button>

                                        <!-- KODE BARU (Tombol Terima & Tolak) -->
<td class="text-center">
    <!-- Tombol Terima -->
    <a href="proses-status.php?id=<?= $data['id']; ?>&status=terima" class="btn btn-success btn-sm me-1">
        Terima
    </a>
    
    <!-- Tombol Tolak -->
    <a href="proses-status.php?id=<?= $data['id']; ?>&status=tolak" class="btn btn-danger btn-sm">
        Tolak
    </a>
</td>

                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" style="text-align: center; color: #6c757d; padding: 50px 0;">Belum ada data jurnal mahasiswa yang diinputkan.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
